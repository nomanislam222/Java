package Interface;
import java.lang.*;
import classes.*;

public interface StudentProfile

{

	public void showInformations();

}
