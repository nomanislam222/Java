package classes;
public abstract class Courses
{	
	                         
	public Courses(){};
	
	public abstract void showdetails();
}