class Noman{  
public static void main(String args[]){  
String s2="Class2"; 
System.out.println(s2.length());
}}  