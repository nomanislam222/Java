class Car{
     public Car( ){  System.out.println("Mazda Car");   }
     public void carObj( ){  Car c =  new Car( );   }
     public static void displayColor( ){
           System.out.println("Red Color");
     }
}
public class MainClass{
      public static void main(String s[ ]){
Car.displayColor();
Car c1 = new Car( ); 
c1.carObj( );

}}