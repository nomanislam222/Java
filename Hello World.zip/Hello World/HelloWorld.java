public class HelloWorld
{

public static void main(String[] args)
{
HelloWorld st1 = new HelloWorld();
System.out.println("Welcome to java programming!");

 }
}