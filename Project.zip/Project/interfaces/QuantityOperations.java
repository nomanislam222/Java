package interfaces;
import classes.*;
public interface QuantityOperations
{
	
	boolean addQuantity(int amount);
    boolean sellQuantity(int amount);
	
	
}