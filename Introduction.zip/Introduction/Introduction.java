public class Introduction
{
public static void main(String[] args)
{
String s1= "Hello";
String s2= "Students!";
System.out.println(s1.concat(s2));
 }
}