public class Student{
      public String name,id,dept;
      public double cgpa;
      public void showinfo(){
              System.out.println("Name: "+name);
              System.out.println("id: "+id);
              System.out.println("dept: "+dept);
              System.out.println("cgpa: "+cgpa);
       }
}