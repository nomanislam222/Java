class Start{
	
	
	public static void main(String args[]){
		
		Shape s1;
		Circle c1 = new Circle(20);
		System.out.println("Circle Area : " + c1.area());
		
		
		Triangle t1 = new Triangle(10, 20);
		s1 = t1;
		System.out.println("Triangle Area : " + s1.area());
	}
}