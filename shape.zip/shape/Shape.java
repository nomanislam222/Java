public abstract class Shape{
	double length;
	
	Shape(double length){
		this.length = length;
	}
	
	double area(){return 0;}
}