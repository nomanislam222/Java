class Triangle extends Shape{
	private double width;
	
	Triangle(double length, double width) {
		super(length);
		this.width = width;
	}
	
	public double area(){
		return (0.5 * length * width);
	}
}