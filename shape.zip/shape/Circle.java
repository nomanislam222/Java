class Circle extends Shape {
	
	Circle(double length) {
		super(length);
	}
	
	public double area(){
		return (3.1416 * length * length);
	}
}