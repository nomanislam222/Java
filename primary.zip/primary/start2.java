public class start2{
    public static void main(String[] args){
        String str1 = "Java";
        String str2 = "World!";
        String str3 = new String ("Java");
        String str4 = new String("Java");
      
        String str5 = str4.toLowerCase();
        String str6 = str1.concat(str2);


System.out.println(str1);
System.out.println(str3.equals(str4));
System.out.println(str5.charAt(2));
System.out.println(str6.indexOf('l'));
System.out.println(str1.substring(1,4));
}
}