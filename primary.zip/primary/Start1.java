class start1{


    public static void main(String args[]){
 

         Student1 st=new Student1();

         Student1 st2=new Student1();

         

         st.id="21-45453-3";

         st.dept="CSE";

         st.name="Noman";

         st.cgpa=3.80;

       

        

         st2.id="21-45454-3";

         st2.dept="CSE";

         st2.name="Ankur Pramanik";

         st2.cgpa=3.80;

        

 
         

        

         st.showinfo();

         st2.showinfo();

       

        



    }

    

    

}