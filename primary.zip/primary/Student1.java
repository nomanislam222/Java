public class Student1{
    
    public String name;
    public String id;
    public double cgpa;
    public String dept;
    public static int course=13;
    

     void showinfo(){
    
         System.out.println("Name: "+name);
         System.out.println("Id: "+id);
         System.out.println("Cgpa: "+cgpa);
         System.out.println("Dept: "+dept);
         System.out.println("Completed Courses: "+course);
     
     }
    
    
}