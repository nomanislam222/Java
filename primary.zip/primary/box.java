public class box{
       public double length,width,height;
       
       public void execute(){
              System.out.println("Length: "+length+"\n"+ "Width: "+width+"\n"+ "Height: "+height+"\n");
            
       }

    public static void main(String[] args){
          box box=new box();
          box.length=6.4;
          box.height=3.2;
         box.width=5.6;
         box.execute();
          
          
          box box1=new box();
          box1.length=9.5;
          box1.height=3.8;
          box1.width=6.5;
          box1.execute();
          
          
          
          }
    
    
}