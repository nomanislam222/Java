class start{
      public static void main(String[] args){
          Student st1 = new Student();
          st1.name="Kamal";
          st1.id="123";
          st1.dept="cse";
          st1.cgpa=3.54;
          st1.showinfo();
          }
}