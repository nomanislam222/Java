class Start
{

	public static void main(String args[])
	{

		Employee e1 = new Employee("Kamal", 31, "BD123-4", "123-1",30000.0,"Prof",20);
                Employee e2 = new Employee("Jamal", 31, "BD123-4", "123-1",30000.0,"Prof",20);
		e1.show_Employee();
                e2.show_Employee();


	}
}