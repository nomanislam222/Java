class Person
{

	protected String name;
	protected int age;
	protected String passportNo;

	Person()
	{

	}

	Person(String n, int age, String p_n)
	{
		this.name=n;
		this.age=age;
		this.passportNo=p_n;
	}

	void show_person()
	{
		System.out.println(name);
		System.out.println(age);
		System.out.println(passportNo);
	}
}