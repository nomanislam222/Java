class Employee extends Person
{
	private String id;
	private double salary;
	private String designation;
	private int yearOfExp;
        Employee(){};
	Employee(  String n, int age, String p_n, String id, double sal, String des, int yrOfExp) 
	{
		
		super(n, age,p_n);
		this.id=id;
		this.salary=sal;
		this.designation= des;
		this.yearOfExp=yrOfExp;
	}

	void show_Employee()
	{
		
		super.show_person();
		System.out.println(id);
		System.out.println(salary);
		System.out.println(yearOfExp);
		System.out.println(designation);
		
	}
}