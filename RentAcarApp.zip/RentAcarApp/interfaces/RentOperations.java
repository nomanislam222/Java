package interfaces;

import java.lang.*;
import classes.Vehicle;


public interface RentOperations
{
	boolean rent(int amount);
	boolean add(int amount);
}


