class Sample
{

public static void main(String arg[])
{
System.out.print("The Number is: "+ 8+2);
System.out.print(4+5);
}
}