class Program
{

public Static void main(string arg)
{
float value = 2.5F ;
System.out.println("The value is:" + value) ;
value = 5.5 ;
System.out.println("The value is:" + value) ;
}
}
