class Student{
int id;
}

class Main{
public static void main(String args[]){
Student s1;
System.out.println(s1.id);
}
}