public class main{
    
      void add(double a,double b){
           double addition = (a+b);
           System.out.println( "Addition       : " + addition);    
       }
        
    void sub(double a,double b){
         double substraction = (a-b);
         System.out.println( "Substraction   : " + substraction);
     }
    
    void mul(double a,double b){
         double multiplication = (a*b);
         System.out.println( "Multiplication : " + multiplication);
     }
    
    void div(double a,double b){
         double division = (a/b);
         System.out.println( "Division       : " + division); 
     }  
}
